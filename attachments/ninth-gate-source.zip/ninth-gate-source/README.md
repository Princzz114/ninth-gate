# Ninth Gate — source

Street-fighter style 2D match (Kael vs Mira). Best of three.

## Core files

- `src/components/NinthGate.tsx` — title, select, HUD, touch controls
- `src/game/engine.ts` — physics, hits, CPU, canvas render
- `src/game/audio.ts` — beeps / music
- `src/routes/index.tsx` — mounts the game
- `src/styles.css` — palette / fonts

Sprites and stage live in the app `public/` folder:
`/sprites/kael`, `/sprites/mira`, `/portraits`, `/stages/rooftop.jpg`

## Controls

A/D move · W jump · S block · J punch · K kick · L special
