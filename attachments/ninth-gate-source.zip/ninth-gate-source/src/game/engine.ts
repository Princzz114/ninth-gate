import { sfx } from "./audio";

export const VW = 1280;
export const VH = 720;
const GROUND = 608;
const GRAVITY = 2100;
const WALK = 320;
const JUMP = -720;

export type FighterId = "kael" | "mira";
export type Anim = "idle" | "walk" | "jump" | "punch" | "kick" | "special" | "hurt";
export type Phase = "intro" | "fight" | "ko" | "over";

type Attack = {
  name: "punch" | "kick" | "special";
  start: number;
  active: number;
  recover: number;
  dmg: number;
  range: number;
  height: number;
  knock: number;
  meterCost: number;
  meterGain: number;
};

const ATK: Record<Attack["name"], Attack> = {
  punch: { name: "punch", start: 0.07, active: 0.11, recover: 0.16, dmg: 8, range: 92, height: 48, knock: 140, meterCost: 0, meterGain: 8 },
  kick: { name: "kick", start: 0.1, active: 0.13, recover: 0.26, dmg: 13, range: 118, height: 36, knock: 220, meterCost: 0, meterGain: 12 },
  special: { name: "special", start: 0.16, active: 0.18, recover: 0.42, dmg: 24, range: 168, height: 70, knock: 380, meterCost: 50, meterGain: 0 },
};

export type Fighter = {
  id: FighterId;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  max: number;
  meter: number;
  anim: Anim;
  t: number;
  hitDone: boolean;
  stun: number;
  invuln: number;
  blocking: boolean;
  alive: boolean;
  cpu: boolean;
  aiT: number;
};

export type Snapshot = {
  phase: Phase;
  time: number;
  round: number;
  winsP: number;
  winsC: number;
  p: Fighter;
  c: Fighter;
  paused: boolean;
  outcome: "win" | "lose" | null;
  overlay: string;
  overlayT: number;
};

export type Actions = {
  left: boolean;
  right: boolean;
  jump: boolean;
  block: boolean;
  punch: boolean;
  kick: boolean;
  special: boolean;
};

const SAVE = "ninth-gate-v1";
export type SaveData = { version: number; wins: number; games: number };

export function loadSave(): SaveData {
  try {
    return { version: 1, wins: 0, games: 0, ...JSON.parse(localStorage.getItem(SAVE) || "{}") };
  } catch {
    return { version: 1, wins: 0, games: 0 };
  }
}

export function writeSave(s: SaveData) {
  try {
    localStorage.setItem(SAVE, JSON.stringify(s));
  } catch {
    /* */
  }
}

function makeFighter(id: FighterId, x: number, facing: 1 | -1, cpu: boolean): Fighter {
  return {
    id,
    name: id === "kael" ? "Kael" : "Mira",
    x,
    y: GROUND,
    vx: 0,
    vy: 0,
    facing,
    hp: 100,
    max: 100,
    meter: 20,
    anim: "idle",
    t: 0,
    hitDone: false,
    stun: 0,
    invuln: 0,
    blocking: false,
    alive: true,
    cpu,
    aiT: 0.4,
  };
}

const ANIMS: Anim[] = ["idle", "walk", "jump", "punch", "kick", "special", "hurt"];

export class Engine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  paused = false;
  phase: Phase = "intro";
  time = 99;
  round = 1;
  winsP = 0;
  winsC = 0;
  p!: Fighter;
  c!: Fighter;
  playerId: FighterId = "kael";
  shake = 0;
  hitStop = 0;
  overlay = "ROUND 1";
  overlayT = 0;
  particles: { x: number; y: number; vx: number; vy: number; life: number }[] = [];
  imgs = new Map<string, HTMLImageElement>();
  stage: HTMLImageElement | null = null;
  readyFlag = false;
  acc = 0;
  last = 0;
  raf = 0;
  listeners = new Set<(s: Snapshot) => void>();
  keys = new Set<string>();
  touch: Actions = { left: false, right: false, jump: false, block: false, punch: false, kick: false, special: false };
  lastA: Actions = { left: false, right: false, jump: false, block: false, punch: false, kick: false, special: false };
  outcome: "win" | "lose" | null = null;
  dead = false;
  _unbind = () => {};

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.resetRound();
    this.bind();
    this.raf = requestAnimationFrame((t) => this.loop(t));
  }

  async ready() {
    const loads: Promise<void>[] = [];
    const stage = new Image();
    stage.crossOrigin = "anonymous";
    stage.src = "/stages/rooftop.jpg";
    loads.push(
      new Promise((res) => {
        stage.onload = () => {
          this.stage = stage;
          res();
        };
        stage.onerror = () => res();
      }),
    );
    for (const who of ["kael", "mira"] as const) {
      for (const a of ANIMS) {
        for (let i = 1; i <= 4; i++) {
          const im = new Image();
          im.crossOrigin = "anonymous";
          im.src = `/sprites/${who}/${a}-${i}.png`;
          loads.push(
            new Promise((res) => {
              im.onload = () => {
                this.imgs.set(`${who}:${a}:${i}`, im);
                res();
              };
              im.onerror = () => res();
            }),
          );
        }
      }
    }
    await Promise.all(loads);
    this.readyFlag = true;
    this.emit();
  }

  bind() {
    const down = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    };
    const up = (e: KeyboardEvent) => this.keys.delete(e.code);
    const clear = () => this.keys.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);
    this._unbind = () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
    };
    if (import.meta.env.DEV || location.search.includes("qa=1")) {
      window.__controlsTest = {
        getX: () => this.p.x,
        getYaw: () => this.p.x,
        getSpeed: () => Math.abs(this.p.vx),
        setKeys: (codes: string[]) => {
          this.keys.clear();
          for (const c of codes) this.keys.add(c);
        },
      };
    }
  }

  subscribe(fn: (s: Snapshot) => void) {
    this.listeners.add(fn);
    fn(this.snap());
    return () => this.listeners.delete(fn);
  }

  snap(): Snapshot {
    return {
      phase: this.phase,
      time: this.time,
      round: this.round,
      winsP: this.winsP,
      winsC: this.winsC,
      p: { ...this.p },
      c: { ...this.c },
      paused: this.paused,
      outcome: this.outcome,
      overlay: this.overlay,
      overlayT: this.overlayT,
    };
  }

  emit() {
    const s = this.snap();
    this.listeners.forEach((f) => f(s));
  }

  start(player: FighterId) {
    this.playerId = player;
    this.winsP = 0;
    this.winsC = 0;
    this.round = 1;
    this.outcome = null;
    this.paused = false;
    this.resetRound();
    this.phase = "intro";
    this.overlay = "ROUND 1";
    this.overlayT = 1.6;
    this.emit();
  }

  resetRound() {
    const cpu: FighterId = this.playerId === "kael" ? "mira" : "kael";
    this.p = makeFighter(this.playerId, 340, 1, false);
    this.c = makeFighter(cpu, 940, -1, true);
    this.time = 99;
    this.particles = [];
    this.shake = 0;
    this.hitStop = 0;
  }

  setTouch(partial: Partial<Actions>) {
    Object.assign(this.touch, partial);
  }

  resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  destroy() {
    this.dead = true;
    cancelAnimationFrame(this.raf);
    this._unbind();
    this.listeners.clear();
  }

  busy(f: Fighter) {
    return f.anim === "punch" || f.anim === "kick" || f.anim === "special" || f.anim === "hurt" || f.stun > 0;
  }

  setAnim(f: Fighter, a: Anim) {
    if (f.anim === a) return;
    f.anim = a;
    f.t = 0;
    f.hitDone = false;
  }

  actions(): Actions {
    const k = this.keys;
    return {
      left: k.has("KeyA") || k.has("ArrowLeft") || this.touch.left,
      right: k.has("KeyD") || k.has("ArrowRight") || this.touch.right,
      jump: k.has("KeyW") || k.has("ArrowUp") || k.has("Space") || this.touch.jump,
      block: k.has("KeyS") || k.has("ArrowDown") || this.touch.block,
      punch: k.has("KeyJ") || k.has("KeyZ") || this.touch.punch,
      kick: k.has("KeyK") || k.has("KeyX") || this.touch.kick,
      special: k.has("KeyL") || k.has("KeyC") || this.touch.special,
    };
  }

  tryAttack(f: Fighter, name: Attack["name"]) {
    if (this.busy(f) || !f.alive) return;
    const a = ATK[name];
    if (f.meter < a.meterCost) return;
    f.meter -= a.meterCost;
    this.setAnim(f, name);
    if (name === "punch") sfx.punch();
    else if (name === "kick") sfx.kick();
    else sfx.special();
  }

  updateFighter(f: Fighter, a: Actions, prev: Actions, dt: number) {
    if (!f.alive) {
      f.y = GROUND;
      f.vx = 0;
      this.setAnim(f, "hurt");
      return;
    }
    f.t += dt;
    f.stun = Math.max(0, f.stun - dt);
    f.invuln = Math.max(0, f.invuln - dt);

    const air = f.y < GROUND - 1;
    const atk = f.anim === "punch" || f.anim === "kick" || f.anim === "special";

    if (atk) {
      const spec = ATK[f.anim as Attack["name"]];
      const total = spec.start + spec.active + spec.recover;
      if (f.t >= total) this.setAnim(f, air ? "jump" : "idle");
    } else if (f.anim === "hurt") {
      if (f.t > 0.32 && f.stun <= 0) this.setAnim(f, air ? "jump" : "idle");
    }

    f.blocking = !this.busy(f) && !air && a.block;

    if (!this.busy(f) && !air) {
      if (a.jump && !prev.jump) {
        f.vy = JUMP;
        this.setAnim(f, "jump");
      } else if (a.punch && !prev.punch) this.tryAttack(f, "punch");
      else if (a.kick && !prev.kick) this.tryAttack(f, "kick");
      else if (a.special && !prev.special) this.tryAttack(f, "special");
    }

    if (!this.busy(f) && !f.blocking) {
      let dir = 0;
      if (a.left) dir -= 1;
      if (a.right) dir += 1;
      if (!air) {
        f.vx = dir * WALK;
        if (dir !== 0) {
          f.facing = dir as 1 | -1;
          if (f.anim !== "jump") this.setAnim(f, "walk");
        } else if (f.anim === "walk") this.setAnim(f, "idle");
      } else {
        f.vx += dir * 900 * dt;
        f.vx = Math.max(-380, Math.min(380, f.vx));
      }
    } else if (!air && !atk) {
      f.vx *= Math.exp(-10 * dt);
    }

    f.vy += GRAVITY * dt;
    f.x += f.vx * dt;
    f.y += f.vy * dt;
    if (f.y >= GROUND) {
      f.y = GROUND;
      f.vy = 0;
      if (f.anim === "jump") this.setAnim(f, "idle");
    }
    f.x = Math.max(80, Math.min(VW - 80, f.x));
    f.meter = Math.min(100, f.meter + dt * 4);
  }

  cpuAct(dt: number): Actions {
    const e = this.c;
    const p = this.p;
    e.aiT -= dt;
    const dx = p.x - e.x;
    const dist = Math.abs(dx);
    const towardLeft = dx < 0;
    const a: Actions = { left: false, right: false, jump: false, block: false, punch: false, kick: false, special: false };
    if (!e.alive) return a;
    e.facing = dx >= 0 ? 1 : -1;
    if (p.anim === "punch" || p.anim === "kick" || p.anim === "special") {
      if (dist < 160 && Math.random() < 0.55) a.block = true;
    }
    if (dist > 150) {
      a.left = towardLeft;
      a.right = !towardLeft;
    } else if (dist < 70) {
      a.left = !towardLeft;
      a.right = towardLeft;
    }
    if (e.aiT <= 0) {
      e.aiT = 0.28 + Math.random() * 0.45;
      if (dist < 170 && !a.block) {
        const r = Math.random();
        if (e.meter >= 50 && r > 0.72) a.special = true;
        else if (r > 0.42) a.kick = true;
        else a.punch = true;
      } else if (dist > 220 && Math.random() < 0.15) a.jump = true;
    }
    return a;
  }

  hitboxes(f: Fighter) {
    if (!(f.anim === "punch" || f.anim === "kick" || f.anim === "special")) return null;
    const spec = ATK[f.anim];
    if (f.t < spec.start || f.t > spec.start + spec.active || f.hitDone) return null;
    const x = f.x + f.facing * (40 + spec.range * 0.35);
    return { x, y: f.y - 90, w: spec.range * 0.55, h: spec.height, spec };
  }

  resolveHits() {
    for (const [atk, def] of [
      [this.p, this.c],
      [this.c, this.p],
    ] as const) {
      const box = this.hitboxes(atk);
      if (!box || !def.alive || def.invuln > 0) continue;
      const dx = Math.abs(box.x - def.x);
      const dy = Math.abs(box.y - (def.y - 90));
      if (dx < box.w * 0.5 + 36 && dy < box.h * 0.5 + 70) {
        atk.hitDone = true;
        atk.meter = Math.min(100, atk.meter + box.spec.meterGain);
        if (def.blocking && def.y >= GROUND - 1) {
          def.hp -= box.spec.dmg * 0.18;
          def.vx = atk.facing * 80;
          sfx.block();
        } else {
          def.hp -= box.spec.dmg;
          def.vx = atk.facing * box.spec.knock;
          def.vy = box.spec.name === "special" ? -240 : -80;
          def.stun = 0.28;
          def.invuln = 0.12;
          this.setAnim(def, "hurt");
          this.shake = Math.min(1, this.shake + 0.35);
          this.hitStop = 0.05;
          sfx.hit();
          for (let i = 0; i < 8; i++) {
            this.particles.push({
              x: def.x,
              y: def.y - 100,
              vx: (Math.random() - 0.5) * 420,
              vy: -Math.random() * 280,
              life: 0.35,
            });
          }
        }
        if (def.hp <= 0) {
          def.hp = 0;
          def.alive = false;
          sfx.ko();
        }
      }
    }
  }

  update(dt: number) {
    if (this.paused || this.phase === "over") return;
    this.overlayT = Math.max(0, this.overlayT - dt);
    if (this.phase === "intro") {
      if (this.overlayT <= 0) {
        this.phase = "fight";
        this.overlay = "FIGHT";
        this.overlayT = 0.7;
      }
      return;
    }
    if (this.hitStop > 0) {
      this.hitStop -= dt;
      return;
    }
    if (this.phase === "fight") {
      this.time -= dt;
      const pa = this.actions();
      const ca = this.cpuAct(dt);
      const empty: Actions = { left: false, right: false, jump: false, block: false, punch: false, kick: false, special: false };
      this.updateFighter(this.p, pa, this.lastA, dt);
      this.updateFighter(this.c, ca, empty, dt);
      this.lastA = { ...pa };
      const gap = this.c.x - this.p.x;
      if (Math.abs(gap) < 70) {
        const mid = (this.p.x + this.c.x) / 2;
        const s = Math.sign(gap || 1);
        this.p.x = mid - 35 * s;
        this.c.x = mid + 35 * s;
      }
      this.resolveHits();
      this.shake = Math.max(0, this.shake - dt * 2.4);
      for (const pt of this.particles) {
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.vy += 600 * dt;
        pt.life -= dt;
      }
      this.particles = this.particles.filter((pt) => pt.life > 0);

      if (!this.p.alive || !this.c.alive || this.time <= 0) {
        this.phase = "ko";
        this.overlayT = 1.8;
        if (!this.p.alive && this.c.alive) {
          this.winsC += 1;
          this.overlay = "K.O.";
        } else if (!this.c.alive && this.p.alive) {
          this.winsP += 1;
          this.overlay = "K.O.";
        } else {
          if (this.p.hp >= this.c.hp) this.winsP += 1;
          else this.winsC += 1;
          this.overlay = "TIME";
        }
      }
    } else if (this.phase === "ko" && this.overlayT <= 0) {
      if (this.winsP >= 2 || this.winsC >= 2) {
        this.phase = "over";
        this.outcome = this.winsP > this.winsC ? "win" : "lose";
        this.overlay = this.outcome === "win" ? "YOU WIN" : "YOU LOSE";
        if (this.outcome === "win") sfx.win();
      } else {
        this.round += 1;
        this.resetRound();
        this.phase = "intro";
        this.overlay = `ROUND ${this.round}`;
        this.overlayT = 1.5;
      }
    }
  }

  frameIndex(f: Fighter) {
    const spd = f.anim === "walk" ? 10 : f.anim === "idle" ? 6 : 12;
    return 1 + (Math.floor(f.t * spd) % 4);
  }

  drawFighter(f: Fighter, cssW: number, cssH: number) {
    const ctx = this.ctx;
    const sx = cssW / VW;
    const sy = cssH / VH;
    const im = this.imgs.get(`${f.id}:${f.anim}:${this.frameIndex(f)}`) || this.imgs.get(`${f.id}:idle:1`);
    const dw = 236 * sx;
    const dh = 236 * sy;
    const x = f.x * sx;
    const y = f.y * sy;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(f.facing, 1);
    if (f.blocking) ctx.globalAlpha = 0.85;
    if (im) ctx.drawImage(im, -dw / 2, -dh + 8 * sy, dw, dh);
    else {
      ctx.fillStyle = f.id === "kael" ? "#7ec8e8" : "#c45c4a";
      ctx.fillRect(-40 * sx, -160 * sy, 80 * sx, 160 * sy);
    }
    ctx.restore();
  }

  render() {
    const ctx = this.ctx;
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    ctx.clearRect(0, 0, w, h);
    const shx = (Math.random() * 2 - 1) * 10 * this.shake * this.shake;
    const shy = (Math.random() * 2 - 1) * 8 * this.shake * this.shake;
    ctx.save();
    ctx.translate(shx, shy);
    if (this.stage) {
      const img = this.stage;
      const scale = Math.max(w / img.width, h / img.height);
      const dw = img.width * scale;
      const dh = img.height * scale;
      ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
    } else {
      ctx.fillStyle = "#12141a";
      ctx.fillRect(0, 0, w, h);
    }
    ctx.fillStyle = "rgba(8,9,12,0.28)";
    ctx.fillRect(0, 0, w, h);
    this.drawFighter(this.p, w, h);
    this.drawFighter(this.c, w, h);
    for (const pt of this.particles) {
      ctx.globalAlpha = Math.max(0, pt.life * 3);
      ctx.fillStyle = "#eceef2";
      ctx.fillRect((pt.x / VW) * w, (pt.y / VH) * h, 3, 3);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  loop(now: number) {
    if (this.dead) return;
    const dt = Math.min(0.05, (now - (this.last || now)) / 1000);
    this.last = now;
    this.acc += dt;
    const step = 1 / 60;
    while (this.acc >= step) {
      this.update(step);
      this.acc -= step;
    }
    this.render();
    this.emit();
    this.raf = requestAnimationFrame((t) => this.loop(t));
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getX: () => number;
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}
