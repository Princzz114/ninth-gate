import { useEffect, useRef, useState, type PointerEvent as PE } from "react";
import { Engine, loadSave, writeSave, type FighterId, type SaveData, type Snapshot } from "@/game/engine";
import { isMuted, setMuted, startMusic, stopMusic, sfx, unlockAudio } from "@/game/audio";

type Screen = "title" | "select" | "fight";

export function NinthGate() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const savedRef = useRef(false);
  const [screen, setScreen] = useState<Screen>("title");
  const [pick, setPick] = useState<FighterId>("kael");
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [muted, setMutedState] = useState(false);
  const [touch, setTouch] = useState(false);
  const [paused, setPaused] = useState(false);
  const [stick, setStick] = useState({ x: 0, y: 0 });
  const [save, setSave] = useState<SaveData>(() =>
    typeof window === "undefined" ? { version: 1, wins: 0, games: 0 } : loadSave(),
  );

  useEffect(() => {
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    setTouch(coarse || window.innerWidth < 820);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new Engine(canvas);
    engineRef.current = engine;
    void engine.ready();
    engine.resize();
    const unsub = engine.subscribe((s) => {
      setSnap(s);
      setPaused(engine.paused);
    });
    const onResize = () => {
      engine.resize();
      setTouch(window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 820);
    };
    window.addEventListener("resize", onResize);
    const ro = new ResizeObserver(onResize);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => {
      unsub();
      engine.destroy();
      stopMusic();
      window.removeEventListener("resize", onResize);
      ro.disconnect();
    };
  }, []);

  useEffect(() => {
    if (snap?.phase !== "over" || savedRef.current) return;
    savedRef.current = true;
    const next = loadSave();
    next.games += 1;
    if (snap.outcome === "win") next.wins += 1;
    writeSave(next);
    setSave(next);
  }, [snap]);

  function begin() {
    unlockAudio();
    startMusic();
    sfx.ui();
    setScreen("select");
  }

  function fight() {
    sfx.ui();
    savedRef.current = false;
    engineRef.current?.start(pick);
    setScreen("fight");
  }

  function hold(key: "left" | "right" | "jump" | "block" | "punch" | "kick" | "special", v: boolean) {
    engineRef.current?.setTouch({ [key]: v });
  }

  function onStick(e: PE<HTMLDivElement>) {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width * 2 - 1;
    const y = (e.clientY - r.top) / r.height * 2 - 1;
    const nx = Math.max(-1, Math.min(1, x));
    const ny = Math.max(-1, Math.min(1, y));
    setStick({ x: nx, y: ny });
    hold("left", nx < -0.25);
    hold("right", nx > 0.25);
    hold("block", ny > 0.45);
  }

  function endStick() {
    setStick({ x: 0, y: 0 });
    hold("left", false);
    hold("right", false);
    hold("block", false);
  }

  const fighting = screen === "fight" && snap && snap.phase !== "over";
  const p = snap?.p;
  const c = snap?.c;

  return (
    <div ref={wrapRef} className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {screen === "title" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-bg/80 px-6 text-center">
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Last city · night match</p>
          <h1 className="mt-3 font-display text-5xl font-medium tracking-tight text-fg sm:text-7xl">NINTH GATE</h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
            A street fight on the last rooftop. Best of three. Stay standing.
          </p>
          <p className="mt-6 text-xs text-muted">
            Wins {save.wins} · Matches {save.games}
          </p>
          <button
            type="button"
            onClick={begin}
            className="mt-8 rounded-xl bg-accent px-8 py-3 text-sm font-medium text-accent-fg transition-transform duration-150 active:scale-[0.98]"
          >
            Enter
          </button>
        </div>
      )}

      {screen === "select" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-bg/85 px-4">
          <p className="text-xs font-medium tracking-widest text-muted uppercase">Choose fighter</p>
          <h2 className="mt-2 font-display text-3xl font-medium">SELECT</h2>
          <div className="mt-8 flex w-full max-w-lg gap-4">
            {(["kael", "mira"] as const).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => setPick(id)}
                className={`flex-1 overflow-hidden rounded-2xl border text-left transition-colors duration-150 ${
                  pick === id ? "border-accent bg-elevated" : "border-line bg-panel"
                }`}
              >
                <img
                  src={`/portraits/${id}.jpg`}
                  alt={id}
                  className="h-52 w-full object-cover object-top sm:h-72"
                />
                <div className="p-4">
                  <div className="font-display text-xl uppercase">{id}</div>
                  <div className="mt-1 text-xs text-muted">{id === "kael" ? "Volt striker" : "Ember closer"}</div>
                </div>
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={fight}
            className="mt-8 rounded-xl bg-accent px-8 py-3 text-sm font-medium text-accent-fg"
          >
            Fight
          </button>
        </div>
      )}

      {fighting && p && c && (
        <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-between gap-3 px-3 pt-[max(0.75rem,env(safe-area-inset-top))] sm:px-5">
          <Bar name={p.name} hp={p.hp} meter={p.meter} flip={false} />
          <div className="flex flex-col items-center pt-1">
            <div className="font-display text-2xl tabular-nums">{Math.max(0, Math.ceil(snap.time))}</div>
            <div className="text-xs text-muted">R{snap.round}</div>
          </div>
          <Bar name={c.name} hp={c.hp} meter={c.meter} flip />
        </div>
      )}

      {fighting && snap.overlayT > 0 && snap.overlay && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="font-display text-5xl tracking-tight text-fg sm:text-7xl">{snap.overlay}</div>
        </div>
      )}

      {fighting && (
        <div className="pointer-events-none absolute right-3 top-20 flex gap-2 sm:right-5">
          <IconBtn
            label={muted ? "Sound" : "Mute"}
            onClick={() => {
              const n = !muted;
              setMuted(n);
              setMutedState(n);
            }}
          />
          <IconBtn
            label={paused ? "Resume" : "Pause"}
            onClick={() => {
              const e = engineRef.current;
              if (!e) return;
              e.paused = !e.paused;
              setPaused(e.paused);
            }}
          />
        </div>
      )}

      {paused && fighting && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg/70">
          <div className="rounded-2xl border border-line bg-elevated p-6 text-center">
            <div className="font-display text-2xl">Paused</div>
            <button
              type="button"
              className="mt-4 rounded-lg bg-accent px-5 py-2 text-sm font-medium text-accent-fg"
              onClick={() => {
                if (engineRef.current) engineRef.current.paused = false;
                setPaused(false);
              }}
            >
              Resume
            </button>
          </div>
        </div>
      )}

      {screen === "fight" && snap?.phase === "over" && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg/80 px-6">
          <div className="w-full max-w-sm rounded-2xl border border-line bg-elevated p-8 text-center">
            <div className="font-display text-4xl">{snap.outcome === "win" ? "YOU WIN" : "YOU LOSE"}</div>
            <p className="mt-3 text-sm text-muted">Best of three · {snap.winsP} – {snap.winsC}</p>
            <button
              type="button"
              className="mt-6 rounded-xl bg-accent px-6 py-3 text-sm font-medium text-accent-fg"
              onClick={() => {
                sfx.ui();
                setScreen("select");
              }}
            >
              Again
            </button>
          </div>
        </div>
      )}

      {fighting && touch && (
        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-8">
          <div
            className="relative h-28 w-28 rounded-full border border-line bg-elevated/70"
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              onStick(e);
            }}
            onPointerMove={(e) => {
              if (e.currentTarget.hasPointerCapture(e.pointerId)) onStick(e);
            }}
            onPointerUp={endStick}
            onPointerCancel={endStick}
          >
            <div
              className="pointer-events-none absolute h-12 w-12 rounded-full bg-accent"
              style={{ left: `calc(50% + ${stick.x * 28}px)`, top: `calc(50% + ${stick.y * 28}px)`, transform: "translate(-50%,-50%)" }}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Pad label="Jump" onDown={() => hold("jump", true)} onUp={() => hold("jump", false)} />
            <Pad label="Block" onDown={() => hold("block", true)} onUp={() => hold("block", false)} />
            <Pad label="Punch" onDown={() => hold("punch", true)} onUp={() => hold("punch", false)} />
            <Pad label="Kick" onDown={() => hold("kick", true)} onUp={() => hold("kick", false)} />
            <Pad label="Special" wide onDown={() => hold("special", true)} onUp={() => hold("special", false)} />
          </div>
        </div>
      )}

      {screen === "fight" && !touch && (
        <p className="pointer-events-none absolute bottom-3 left-0 right-0 text-center text-xs text-muted">
          A/D move · W jump · S block · J punch · K kick · L special
        </p>
      )}
    </div>
  );
}

function Bar({ name, hp, meter, flip }: { name: string; hp: number; meter: number; flip: boolean }) {
  return (
    <div className={`min-w-0 flex-1 ${flip ? "text-right" : ""}`}>
      <div className="mb-1 text-xs font-medium uppercase tracking-wide">{name}</div>
      <div className="h-2 overflow-hidden rounded-sm bg-panel">
        <div
          className={`h-full ${flip ? "ml-auto bg-mira" : "bg-kael"}`}
          style={{ width: `${Math.max(0, hp)}%` }}
        />
      </div>
      <div className="mt-1 h-1 overflow-hidden rounded-sm bg-panel">
        <div className={`h-full bg-accent ${flip ? "ml-auto" : ""}`} style={{ width: `${Math.max(0, meter)}%` }} />
      </div>
    </div>
  );
}

function IconBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="pointer-events-auto rounded-lg border border-line bg-elevated/80 px-3 py-2 text-xs font-medium"
    >
      {label}
    </button>
  );
}

function Pad({
  label,
  onDown,
  onUp,
  wide,
}: {
  label: string;
  onDown: () => void;
  onUp: () => void;
  wide?: boolean;
}) {
  return (
    <button
      type="button"
      className={`h-12 rounded-xl border border-line bg-elevated/80 text-xs font-medium ${wide ? "col-span-2" : "w-16"}`}
      onPointerDown={(e) => {
        e.preventDefault();
        onDown();
      }}
      onPointerUp={onUp}
      onPointerCancel={onUp}
    >
      {label}
    </button>
  );
}
